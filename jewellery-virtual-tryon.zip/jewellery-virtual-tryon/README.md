# Onkarnath Agrawal Sarraf — Jewellery Virtual Try-On Prototype

## What it does
- Upload a jewellery image.
- Start the front camera.
- Uses MediaPipe Pose Landmarker to track shoulders in real time.
- Places the uploaded necklace image on the customer.
- Manual size / horizontal / vertical / opacity controls.
- Captures the try-on result as a JPG.

## Important
For the cleanest overlay, upload a transparent PNG of the necklace with the background removed.

## Run locally
Because camera access requires a secure context, run a local web server instead of opening `index.html` directly.

Example:

```bash
python -m http.server 8080
```

Then open:

http://localhost:8080

## Deploy
This single-page prototype can be deployed to Firebase Hosting, Cloudflare Pages, Netlify, Vercel, or any HTTPS static hosting.

## Next production steps
1. Add Firebase product catalogue and admin upload.
2. Add automatic background removal / transparent asset generation.
3. Add earrings using face landmarks.
4. Add bangles using hand landmarks.
5. Add product price, weight, SKU and live gold-rate integration.
6. Add WhatsApp enquiry / lead capture.
7. Move inference to a Web Worker for smoother high-FPS tracking on lower-end phones.
8. Add a proper 3D AR pipeline for perspective-accurate jewellery.
